# src/sydweather_utils/core.py
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Dict, Union
from sklearn.model_selection import train_test_split

# ... deja el resto de imports y funciones tal como están (incl. build_features)

def time_split(
    df: pd.DataFrame,
    target: str,
    *,
    train_cutoff: Union[str, pd.Timestamp],
    val_cutoff:   Union[str, pd.Timestamp],
) -> Dict[str, pd.DataFrame]:
    """
    Time-based split using exact datetime cutoffs.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe with a DatetimeIndex.
    target : str
        Name of the target column.
    train_cutoff : str | pd.Timestamp
        All rows with index < train_cutoff go to TRAIN.
    val_cutoff : str | pd.Timestamp
        All rows with index >= train_cutoff and < val_cutoff go to VAL.
        All rows with index >= val_cutoff go to TEST.

    Returns
    -------
    dict
        {
            "X_train","y_train","X_val","y_val","X_test","y_test",
            "feature_cols","cutoffs"
        }

    Raises
    ------
    TypeError
        If index is not a DatetimeIndex.
    KeyError
        If target column is missing.
    ValueError
        If cutoffs are invalid or inconsistent.
    """
    if not isinstance(df.index, pd.DatetimeIndex):
        raise TypeError("`df` must have a DatetimeIndex.")

    if target not in df.columns:
        raise KeyError(f"Target '{target}' not found in DataFrame.")

    # Normalize cutoffs to Timestamps, align tz with index if needed
    ts_train = pd.to_datetime(train_cutoff)
    ts_val   = pd.to_datetime(val_cutoff)

    if ts_train >= ts_val:
        raise ValueError("`train_cutoff` must be strictly earlier than `val_cutoff`.")

    # If index is tz-aware and cutoffs are naive, localize to index tz
    if df.index.tz is not None:
        if ts_train.tzinfo is None:
            ts_train = ts_train.tz_localize(df.index.tz)
        if ts_val.tzinfo is None:
            ts_val = ts_val.tz_localize(df.index.tz)

    # Splits
    df_train = df[df.index < ts_train]
    df_val   = df[(df.index >= ts_train) & (df.index < ts_val)]
    df_test  = df[df.index >= ts_val]

    if len(df_train) == 0 or len(df_val) == 0 or len(df_test) == 0:
        raise ValueError(
            "Empty split detected. Check your cutoffs cover the index range: "
            f"[{df.index.min()} .. {df.index.max()}] with "
            f"train_cutoff={ts_train}, val_cutoff={ts_val}."
        )

    feature_cols = [c for c in df.columns if c != target]

    X_train, y_train = df_train[feature_cols], df_train[target]
    X_val,   y_val   = df_val[feature_cols],   df_val[target]
    X_test,  y_test  = df_test[feature_cols],  df_test[target]

    return {
        "X_train": X_train, "y_train": y_train,
        "X_val":   X_val,   "y_val":   y_val,
        "X_test":  X_test,  "y_test":  y_test,
        "feature_cols": feature_cols,
        "cutoffs": {"train_cutoff": ts_train, "val_cutoff": ts_val},
    }
